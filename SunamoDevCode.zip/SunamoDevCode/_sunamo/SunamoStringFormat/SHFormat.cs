namespace SunamoDevCode._sunamo.SunamoStringFormat;
internal class SHFormat
{
    internal static string Format4(string v, params Object[] o)
    {
        return string.Format(v, o);
    }
}
