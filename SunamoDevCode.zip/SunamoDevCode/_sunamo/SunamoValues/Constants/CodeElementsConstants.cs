namespace SunamoDevCode._sunamo.SunamoValues.Constants;


internal class CodeElementsConstants
{
    internal const string NopeValue = "Nope";
    internal const string NoneValue = "None";
    internal const string SingleCommentCsharp = "//";
    internal const string XmlDocumentationCsharp = "///";
}