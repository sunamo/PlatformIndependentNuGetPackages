namespace SunamoDevCode._sunamo.SunamoValues.Values;


internal class SunamoNotTranslateAble
{
    internal const string From = " - From";
    internal const string SessI18n = "sess.i18n(";
    internal const string SessI18nShort = "sess.i18n(";
    internal const string RLDataEn = "RLData.en[";
    internal const string RLDataCs = "RLData.cs[";
    internal const string RLDataEn2 = "RLDataEn[";
    internal const string XlfKeysDot = "XlfKeys.";
    internal const string on = "on";
    internal const string Orient = "Orient";
}