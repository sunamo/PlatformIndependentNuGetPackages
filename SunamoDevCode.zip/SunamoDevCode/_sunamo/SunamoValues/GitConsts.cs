namespace SunamoDevCode._sunamo.SunamoValues;


internal class GitConsts
{
    internal const string startingHead = "<<<<<<<";
    internal const string delimiter = "=======";
    internal const string end = ">>>>>>>";
}