namespace SunamoDevCode._sunamo.SunamoInterfaces.Interfaces;


internal interface ITypedLoggerBase
{
}
