namespace SunamoDevCode._sunamo.SunamoInterfaces.Interfaces;


internal interface IDumpAsString
{
    string DumpAsString(string operation, /*DumpAsStringHeaderArgs*/ Object dumpAsStringHeaderArgs);
}