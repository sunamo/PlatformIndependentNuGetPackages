namespace SunamoPS._public.SunamoInterfaces.Interfaces;

public interface INpmBashBuilderPS
{
    void I(string args = null);
}