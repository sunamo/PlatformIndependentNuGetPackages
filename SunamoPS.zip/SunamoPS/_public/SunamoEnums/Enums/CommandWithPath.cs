namespace SunamoPS._public.SunamoEnums.Enums;

public enum CommandWithPath
{
    dos2unix
}