namespace SunamoPS._public.SunamoArgs;

public class InvokeProcessArgsPS
{
    public string workingDir = null;
}