namespace SunamoPS._sunamo.SunamoFileExtensions;

internal class AllExtensions
{
    internal static string exe = ".exe";
}