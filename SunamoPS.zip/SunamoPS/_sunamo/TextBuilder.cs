namespace SunamoPS._sunamo;

internal class TextBuilder
{
}